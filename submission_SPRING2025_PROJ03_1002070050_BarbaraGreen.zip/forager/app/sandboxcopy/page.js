
import Message from "../../components/Message";
import { DataMushroomListPercent } from "@/components/MushroomList";
/* import {mushroomslistpercent,pill,pillg1,pillg2,pillg3,pl} from '../../data/development' */
import {TitleFilterSettings, FilterSettings} from '@/components/FilterSettings'
import { TitlePillList } from "@/components/PillList";
export default function SandboxCopyPage() {
    return (
       //<FilterSettings pills = {pill}  />
{/* <TitleFilterSettings pills={[...pillg1, ...pillg2, ...pillg3]} /> */}

    );
}
  